package StudentManageSystemFullFunction;

import StudentManageSystemFullFunction.Admin.Login;
import jdk.nashorn.internal.ir.CallNode;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/5 14:46
 * @Java version: 1.8.0_361
 * @Description:NULL
 */
public class Entrance {
    public static void main(String[] args) {
        Login login = new Login();
        login.loginMianMenu();
    }
}
