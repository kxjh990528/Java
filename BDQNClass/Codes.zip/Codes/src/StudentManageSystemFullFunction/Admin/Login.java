package StudentManageSystemFullFunction.Admin;

import StudentManageSystemFullFunction.ManageSystem.Manager;

import java.util.Scanner;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/3 16:49
 * @Java version: 1.8.0_361
 * @Description:登录界面
 * 拥有注册，登录，注销等功能
 */

//登录界面
public class Login {
    Scanner scanner = new Scanner(System.in);
    public Administrator []adminlist = new Administrator[5];//定义最大管理员个数为10个
    public static int admin_num = 0;   //管理员个数

    //static boolean is_registered = false;  //是否注册,true为注册，false为未注册
    public boolean is_login = false;   //是否登录，true为已登入，false为未登入

    //登录界面主菜单
    public void loginMianMenu(){
        String flag;
        do {
            System.out.println("\t\t欢迎使用学生管理系统");
            System.out.println(">>>1.注册 2.登录  3.进入学生管理系统 4.登出 5.退出");
            System.out.print("请输入选择的功能：");
            int controll = scanner.nextInt();
            switch (controll){
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    enterSystem();
                    break;
                case 4:
                    logout();
                    break;
                case 5:
                    System.exit(1);
                    break;
                default:
                    System.out.println("输入有误！");
            }

            System.out.println("你是否想继续操作:(y|n)");
            flag = scanner.next();  //接收输入字符串
        }while (flag.equals("y"));
        System.out.println("系统退出");
    }

    //注册
    public void register() {
        if (admin_num >= adminlist.length){
            System.out.println("管理员数量已满，添加失败！");
            //return; //退出方法
            this.loginMianMenu();
        }else {
            System.out.println("管理员注册>>>");
            Administrator administrator = new Administrator();
            System.out.println("请输入管理员账号：");
            administrator.setAdmin_id(scanner.nextInt());
            for (int i = 0; i < admin_num; i++) {
                if (administrator.getAdmin_id() == adminlist[i].getAdmin_id()){
                    System.out.println("账号已经存在，请重新注册");
                    this.loginMianMenu();
                }
            }
            System.out.println("请输入密码：");
            administrator.setPassword(scanner.next());
            if (admin_num < 10){
                adminlist[admin_num] = administrator;
                admin_num++;
                System.out.println("注册成功！");
                System.out.println("请牢记用户信息：\n用户账号：" + administrator.getAdmin_id() + "\t密码：" + administrator.getPassword());
                System.out.println();
                this.loginMianMenu();
            }
        }

    }

    //登录
    public void login(){
        if (admin_num == 0){
            System.out.println("还未有管理员注册！请先注册！");
        }else {
            Administrator administrator = new Administrator();
            System.out.println(">>>管理员登录：");
            //登录次数限制器
            for (int i = 1; i <= 3; i++) {
                System.out.print("请输入管理员账号：");
                administrator.setAdmin_id(scanner.nextInt());
                System.out.print("请输入密码：");
                administrator.setPassword(scanner.next());
                for (int j = 0; j < admin_num; j++) {
                    if (administrator.getAdmin_id() == adminlist[j].getAdmin_id() &&
                            administrator.getPassword().equals(adminlist[j].getPassword())){
                        System.out.println("登录成功！");
                        System.out.println("欢迎使用学生管理系统，目前登录账号为：" + administrator.getAdmin_id());
                        is_login = true;
                        this.loginMianMenu();
                        break;
                    }else if (j == admin_num - 1){
                        System.out.println("登录失败，用户名或密码输入错误!你还有" + (3 - i) + "次机会！");
                    }
                }
            }
            this.loginMianMenu();
        }
    }

    //进入管理系统
    public void  enterSystem(){
        if (admin_num == 0 ){
            System.out.println("请先注册！");
            System.out.println();
            this.loginMianMenu();
        }else{
            if (is_login == false){
                System.out.println("请先登录！");
                System.out.println();
                this.loginMianMenu();
            }else if (is_login == true){
                Manager manager = new Manager();
                manager.mainMenu();
            }
        }

    }

    //登出
    public void  logout(){
        if (admin_num == 0){
            System.out.println("请先注册！");
        }else if (admin_num != 0 && is_login == false){
            System.out.println("请先登录！");
        }else if (admin_num != 0 && is_login == true){
            System.out.println("[学生管理系统>登出]");
            System.out.println("成功登出！");
            is_login = false;
        }
    }
}
