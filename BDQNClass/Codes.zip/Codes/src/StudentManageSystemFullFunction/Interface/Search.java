package StudentManageSystemFullFunction.Interface;

import StudentManageSystemFullFunction.ManageSystem.People;
import StudentManageSystemFullFunction.ManageSystem.Student;
import StudentManageSystemFullFunction.ManageSystem.Teacher;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/6 0:14
 * @Java version: 1.8.0_361
 * @Description:NULL
 */
public interface Search {
    //显示信息
    public abstract void show();

    //按姓名查找
    public abstract void searchByName(String name);
}
