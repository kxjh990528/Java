package StudentManageSystemFullFunction.Interface;

import StudentManageSystemFullFunction.ManageSystem.People;

import java.util.Objects;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/5 10:38
 * @Java version: 1.8.0_361
 * @Description:NULL
 */

//删除接口
public interface Delete {
    public abstract boolean deletePerson(int id);
}
