package StudentManageSystemFullFunction.Interface;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/5 11:23
 * @Java version: 1.8.0_361
 * @Description:NULL
 */

//修改信息接口
public interface Alter {
    public abstract void alterName(int id);
    public abstract void alterAge(int id);
    public abstract void applyForSuspension(int id);
    public abstract void goBackToSchool(int id);
}
