package StudentManageSystemFullFunction.Interface;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/4 20:55
 * @Java version: 1.8.0_361
 * @Description:NULL
 */

//添加接口
public interface AddPerson {
    public abstract void addPerson();
}
