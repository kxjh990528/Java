package StudentManageSystemFullFunction.ManageSystem;

import StudentManageSystemFullFunction.Interface.Search;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/3 16:48
 * @Java version: 1.8.0_361
 * @Description:NULL
 */
public class People implements Search {
    private String name; //姓名
    private int age;    //年龄

    public People() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    //按姓名查找
    @Override
    public void searchByName(String name) {
    }

    //显示信息
    @Override
    public void show(){
        System.out.print("\t姓名：" + this.getName() + "\t年龄：" + this.getAge());
    }

}
