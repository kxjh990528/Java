package StudentManageSystemFullFunction.ManageSystem;

import StudentManageSystemFullFunction.Interface.AddPerson;
import StudentManageSystemFullFunction.Interface.Alter;
import StudentManageSystemFullFunction.Interface.Delete;
import StudentManageSystemFullFunction.Interface.Search;

import java.util.Objects;
import java.util.Scanner;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/3 16:49
 * @Java version: 1.8.0_361
 * @Description:NULL
 */
public class Student extends People implements AddPerson, Search, Delete, Alter {
    private int stu_id; //学号
    private short state;    //状态 0 在读  1 休学

    public Student() {
    }

    Scanner scanner = new Scanner(System.in);
    Manager manager = new Manager();

    public int getStu_id() {
        return stu_id;
    }

    public void setStu_id(int stu_id) {
        this.stu_id = stu_id;
    }

    public short getState() {
        return state;
    }

    public void setState(short state) {
        this.state = state;
    }

    //添加学生
    @Override
    public void addPerson(){
        System.out.println("录入添加学生信息>>>");
        System.out.print("请输入学号：");
        this.setStu_id(scanner.nextInt());
        for (int i = 0; i < Manager.count; i++) {

        }
        System.out.print("请输入姓名：");
        super.setName(scanner.next());
        System.out.print("请输入年龄：");
        super.setAge(scanner.nextInt());
        this.setState((short) 0);
        System.out.println("添加成功！");
    }

    //按姓名查找
    @Override
    public void searchByName(String name) {
        int pos = super.getName().indexOf(name);
        if (pos != -1) {
            this.show();
        }
    }

    //显示所有学生
    @Override
    public void show() {
        System.out.println("这是一名学生");
        System.out.print("学号：" + this.getStu_id());
        super.show();
        System.out.println("\t在读状态：" + (this.getState() == 0 ? "在读":"休学"));
    }

    //删除学生
    @Override
    public boolean deletePerson(int id) {
        if (this.getStu_id() == id){
            this.show();
            System.out.println("删除成功！");
            return true;
        }
        return false;
    }

    //修改学生姓名
    public void alterName(int id){
        if (this.getStu_id() == id){
            System.out.println("修改前：");
            this.show();
            System.out.println("请输入修改后的姓名：");
            super.setName(scanner.next());
            System.out.println("修改成功！");
            this.show();
        }
    }

    //修改年龄
    @Override
    public void alterAge(int id){
        if (this.getStu_id() == id){
            System.out.println("修改前：");
            this.show();
            System.out.println("请输入修改后的年龄：");
            super.setAge(scanner.nextInt());
            System.out.println("修改成功！");
            this.show();
        }
    }

    //办理休学
    @Override
    public void applyForSuspension(int id) {
        if (this.getStu_id() == id){
            if (this.getState() == (short) 1){
                System.out.println("该生已经在休学中，请勿重复申请！");
            }else if (this.getState() == (short) 0){
                this.setState((short) 1);
                System.out.println("申请成功！");
                this.show();
            }
        }
    }

    //办理复学
    @Override
    public void goBackToSchool(int id) {
        if (this.getStu_id() == id) {
            if (this.getState() == (short) 0) {
                System.out.println("该生已经复学，请勿重复申请！");
            } else if (this.getState() == (short) 1) {
                this.setState((short) 0);
                System.out.println("申请成功！");
                this.show();
            }
        }
    }
}
