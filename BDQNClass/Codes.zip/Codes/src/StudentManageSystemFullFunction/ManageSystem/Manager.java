package StudentManageSystemFullFunction.ManageSystem;

import StudentManageSystemFullFunction.Interface.Search;

import java.util.Scanner;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/4 20:30
 * @Java version: 1.8.0_361
 * @Description:学生管理系统主界面
 */
public class Manager {
    //输入对象 属性
    Scanner scanner = new Scanner(System.in);
    //定义学生数组用于存储人员信息: 10
    People[] peolist = new People[10];
    //控制成员人数
    static public int count = 0;

    //主菜单
    public void mainMenu(){
        System.out.println("\t\t欢迎使用学工管理系统");
        System.out.println(">>>1.添加成员 2.查询成员信息 3.删除成员 4.修改成员信息 5.退出");
        System.out.print("请选择功能:");
        int tmp = scanner.nextInt();
        switch (tmp){
            case 1:
                this.addPerson();
                break;
            case 2:
                this.menuSearchPerson();
                break;
            case 3:
                this.delete();
                break;
            case 4:
                this.menuAlterInfo();
                break;
            case 5:
                //退出
                System.exit(1);
                break;
            default:
                System.out.println("输入有误，请重新输入");
                this.mainMenu();
                break;
        }
    }

    //添加菜单
    public void addPerson() {
        System.out.println("请输入添加成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count >= peolist.length) {
            System.out.println("成员已满，请勿继续添加！");
            this.mainMenu();
        } else {
            if (choose == 1) {
                Student student = new Student();
                student.addPerson();
                peolist[count] = student;
                count++;
            } else if (choose == 2) {
                if (count >= peolist.length) {
                    System.out.println("成员已满，请勿继续添加！");
                    this.mainMenu();
                } else {
                    Teacher teacher = new Teacher();
                    teacher.addPerson();
                    peolist[count] = teacher;
                    count++;
                }
            } else {
                System.out.println("输入错误，请重新输入!");
                this.mainMenu();
            }
            //询问
            System.out.println("是否想继续添加(y|n)？");
            String flag = scanner.next();
            if (flag.equals("y"))
                this.addPerson();
            else
                this.mainMenu();
        }
    }

    //删除成员
    public void delete(){
        System.out.println("请输入删除成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count == 0){
            System.out.println("成员数量为空，请添加成员！");
            this.mainMenu();
        }else {
            if (choose == 1){
                System.out.println("请输入要删除的学生学号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student){
                        Student student = (Student) peolist[i];
                        if (student.deletePerson(id)){
                            for (int j = i; j < count; j++) {
                                peolist[j] = peolist[j + 1];
                            }
                        }
                    }
                }

            }else if (choose == 2){
                if (count == 0){
                    System.out.println("成员为空，请添加成员！！");
                    this.mainMenu();
                }else {
                    System.out.println("请输入要删除教工的工号：");
                    int id = scanner.nextInt();
                    for (int i = 0; i < count; i++) {
                        if (peolist[i] instanceof Teacher){
                            Teacher teacher = (Teacher) peolist[i];
                            if (teacher.deletePerson(id)){
                                for (int j = i; j < count; j++) {
                                    peolist[j] = peolist[j + 1];
                                }
                            }
                        }
                    }
                }
            }else {
                System.out.println("输入错误，请重新输入!");
                this.mainMenu();
            }
        }
        //询问
        System.out.println("是否想继续操作(y|n)?");
        String flag = scanner.next();
        if(flag.equals("y"))
            this.delete();
        else
            this.mainMenu();
    }

    //二级菜单：查询
    public void menuSearchPerson(){
        System.out.println("\t\t学工管理系统（二级菜单）");
        System.out.println(">>>1.按姓名查找 2.显示所有 3.返回上级菜单 4.退出");
        System.out.print("请选择功能:");
        int choose = scanner.nextInt();
        switch (choose){
            case 1:
                this.searchByName();
                break;
            case 2:
                this.showAll();
                break;
            case 3:
                this.mainMenu();
                break;
            case 4:
                System.exit(1);
                break;
            default:
                System.out.println("输入有误，请重新输入");
                this.menuSearchPerson();
                break;
        }
    }

    //显示信息
    public void showAll(){
        System.out.println("请输入查询成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if(count == 0){
            System.out.println("成员数量为空，请先添加！");
        }else {
            if (choose == 1){
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student){
                        Student student = new Student();
                        student = (Student) peolist[i];
                        student.show();
                    }
                }
                //询问
                System.out.println("是否想继续操作(y|n)？");
                String flag = scanner.next();
                if(flag.equals("y"))
                    this.showAll();
                else
                    this.mainMenu();
            } else if (choose == 2){
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Teacher) {
                        Teacher teacher = new Teacher();
                        teacher = (Teacher) peolist[i];
                        teacher.show();
                    }
                }
                //询问
                System.out.println("是否想继续操作(y|n)？");
                String flag = scanner.next();
                if(flag.equals("y"))
                    this.showAll();
                else
                    this.mainMenu();
            }else {
                System.out.println("输入错误，请重新输入!");
                this.menuSearchPerson();
            }
        }
    }

    //按姓名查询
    public void searchByName() {
        System.out.println("请输入查询成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count == 0){
            System.out.println("成员数量为空，请先添加！");
            this.mainMenu();
        }else {
            if (choose == 1){
                System.out.println(">>>请输入学生姓名:（支持模糊查询）");
                String name = scanner.next();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student){
                        Student student = (Student) peolist[i];
                        student.searchByName(name);
                    }
                }
                //询问
                System.out.println("是否想继续操作(y|n)?");
                String flag = scanner.next();
                if(flag.equals("y"))
                    this.searchByName();
                else
                    this.menuSearchPerson();
            } else if (choose == 2){
                System.out.println(">>>请输入教工姓名:（支持模糊查询）");
                String name = scanner.next();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Teacher) {
                        Teacher teacher = (Teacher) peolist[i];
                        teacher.searchByName(name);
                    }
                }
                //询问
                System.out.println("是否想继续操作(y|n)?");
                String flag = scanner.next();
                if(flag.equals("y"))
                    this.searchByName();
                else
                    this.menuSearchPerson();
            }else {
                System.out.println("输入错误，请重新输入!");
                this.menuSearchPerson();
            }
        }
    }

    //二级菜单：修改成员信息菜单
    public void menuAlterInfo(){
        System.out.println("\t\t学教信息修改系统（二级菜单）");
        System.out.println(">>>1.修改成员姓名 2.修改成员年龄 3.修改成员状态 4.返回上级菜单 5.退出");
        System.out.print("请选择功能:");
        int tmp = scanner.nextInt();
        switch (tmp){
            case 1:
                this.alterName();
                break;
            case 2:
                this.alterAge();
                break;
            case 3:
                this.regularService();
                break;
            case 4:
                this.mainMenu();
                break;
            case 5:
                System.exit(1);
                break;
            default:
                System.out.println("输入有误，请重新输入");
                this.menuAlterInfo();
                break;
        }
    }

    //修改姓名
    public void alterName(){
        System.out.println("请输入要修改姓名的成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count == 0){
            System.out.println("成员数量为空，请先添加！");
        }else {
            if (choose == 1){
                System.out.println("请输入要修改姓名的学生学号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student){
                        Student student = new Student();
                        student = (Student) peolist[i];
                        student.alterName(id);
                        peolist[i] = student;
                    }
                }
            } else if (choose == 2){
                System.out.println("请输入要修改姓名的教工工号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Teacher) {
                        Teacher teacher = new Teacher();
                        teacher = (Teacher) peolist[i];
                        teacher.alterName(id);
                        peolist[i] = teacher;
                    }
                }
            }else {
                System.out.println("输入错误，请重新输入!");
                this.menuSearchPerson();
            }
        }
        //询问
        System.out.println("是否想继续操作(y|n)？");
        String flag = scanner.next();
        if(flag.equals("y"))
            this.alterName();
        else
            this.menuAlterInfo();
    }

    //修改年龄
    public void alterAge(){
        System.out.println("请输入要修改年龄的成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count == 0){
            System.out.println("成员数量为空，请先添加！");
            this.mainMenu();
        }else {
            if (choose == 1){
                System.out.println("请输入要修改姓名的学生学号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student) {
                        Student student = new Student();
                        student = (Student) peolist[i];
                        student.alterAge(id);
                    }
                }
            } else if (choose == 2){
                System.out.println("请输入要修改姓名的教工工号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Teacher) {
                        Teacher teacher = new Teacher();
                        teacher = (Teacher) peolist[i];
                        teacher.alterAge(id);
                    }
                }
            }else {
                System.out.println("输入错误，请重新输入!");
                this.menuSearchPerson();
            }
        }
        //询问
        System.out.println("是否想返回上一级y|n");
        String flag = scanner.next();
        if(flag.equals("y"))
            this.mainMenu();
        else
            this.menuAlterInfo();
    }

    //办理休学菜单
    public void regularService(){
        System.out.println("\t\t常规业务菜单");
        System.out.println(">>>1.办理休学/休假(通过学工号)  2.办理复学/复工  3.返回上级菜单 4.退出");
        System.out.print("请选择功能:");
        int tmp = scanner.nextInt();
        switch (tmp){
            case 1:
                this.suspension();
                break;
            case 2:
                this.goBack();
                break;
            case 3:
                this.mainMenu();
                break;
            case 4:
                System.exit(1);
                break;
            default:
                System.out.println("输入有误，请重新输入");
                this.regularService();
                break;
        }
    }

    //办理休学/休假
    public void suspension(){
        System.out.println("请输入要办理休学/休假的成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count == 0){
            System.out.println("成员为空，请添加成员！");
            this.mainMenu();
        }else {
            if (choose == 1) {
                System.out.println("请输入要办理休学的学生学号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student) {
                        Student student = (Student) peolist[i];
                        student.applyForSuspension(id);
                        peolist[i] = student;
                    }
                }
            }else if (choose == 2){
                System.out.println("请输入要办理休假的教师工号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Teacher) {
                        Teacher teacher = (Teacher) peolist[i];
                        teacher.applyForSuspension(id);
                        peolist[i] = teacher;
                    }
                }
            }else {
                System.out.println("输入错误，请重新输入!");
                this.mainMenu();
            }
        }
        //询问
        System.out.println("是否想继续操作(y|n)？");
        String flag = scanner.next();
        if(flag.equals("y"))
            this.suspension();
        else
            this.regularService();
    }

    //复学/复工
    public void goBack(){
        System.out.println("请输入要办理复工/复学的成员职称（1.学生/2.老师）：");
        int choose = scanner.nextInt();
        if (count == 0){
            System.out.println("成员为空，请添加成员！");
            this.mainMenu();
        }else {
            if (choose == 1){
                System.out.println("请输入要办理复学的学生学号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student) {
                        Student student = (Student) peolist[i];
                        student.goBackToSchool(id);
                        peolist[i] = student;
                    }
                }
            }else if (choose == 2){
                System.out.println("请输入要办理返岗的教师工号：");
                int id = scanner.nextInt();
                for (int i = 0; i < count; i++) {
                    if (peolist[i] instanceof Student) {
                        Teacher teacher = (Teacher) peolist[i];
                        teacher.goBackToSchool(id);
                        peolist[i] = teacher;
                    }
                }
            }else {
                System.out.println("输入错误，请重新输入!");
                this.mainMenu();
            }
        }
        //询问
        System.out.println("是否想继续操作(y|n)？");
        String flag = scanner.next();
        if(flag.equals("y"))
            this.goBack();
        else
            this.regularService();
    }
}
