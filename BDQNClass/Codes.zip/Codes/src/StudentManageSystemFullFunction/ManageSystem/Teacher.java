package StudentManageSystemFullFunction.ManageSystem;

import StudentManageSystemFullFunction.Interface.AddPerson;
import StudentManageSystemFullFunction.Interface.Alter;
import StudentManageSystemFullFunction.Interface.Delete;
import StudentManageSystemFullFunction.Interface.Search;

import java.util.Scanner;

/**
 * @Author: 林宇扬
 * @Date: 2023/3/4 20:35
 * @Java version: 1.8.0_361
 * @Description:NULL
 */
public class Teacher extends People implements AddPerson, Search, Delete, Alter {
    private int tea_id; //工号
    private short state;    //状态 0 在岗  1 休假

    public Teacher() {
    }

    Scanner scanner = new Scanner(System.in);
    Manager manager = new Manager();

    public int getTea_id() {
        return tea_id;
    }

    public void setTea_id(int tea_id) {
        this.tea_id = tea_id;
    }

    public short getState() {
        return state;
    }

    public void setState(short state) {
        this.state = state;
    }

    //添加教工
    @Override
    public void addPerson() {
        System.out.println("录入教工信息>>>");
        System.out.print("请输入工号：");
        this.setTea_id(scanner.nextInt());
        System.out.print("请输入姓名：");
        super.setName(scanner.next());
        System.out.print("请输入年龄：");
        super.setAge(scanner.nextInt());
        this.setState((short) 0);
        System.out.println("添加成功！");
    }

    //按姓名查找
    @Override
    public void searchByName(String name){
        int pos = super.getName().indexOf(name);
        if (pos != -1){
            this.show();
        }
    }

    //显示教工信息
    @Override
    public void show() {
        System.out.println("这是一名教工");
        System.out.print("工号：" + this.getTea_id());
        super.show();
        System.out.println("\t工作状态：" + (this.getState() == 0 ? "在岗":"休假"));
    }

    //删除教工
    @Override
    public boolean deletePerson(int id) {
        if (this.getTea_id() == id){
            this.show();
            System.out.println("删除成功！");
            return true;
        }
        return false;
    }

    //修改教工姓名
    @Override
    public void alterName(int id) {
        if (this.getTea_id() == id){
            System.out.println("修改前：");
            this.show();
            System.out.println("请输入修改后的姓名：");
            super.setName(scanner.next());
            System.out.println("修改成功！");
            this.show();
        }
    }

    //修改年龄
    @Override
    public void alterAge(int id){
        if (this.getTea_id() == id){
            System.out.println("修改前：");
            this.show();
            System.out.println("请输入修改后的年龄：");
            super.setAge(scanner.nextInt());
            System.out.println("修改成功！");
            this.show();
        }
    }

    //办理休假
    @Override
    public void applyForSuspension(int id) {
        if (this.getTea_id() == id){
            if (this.getState() == (short) 1){
                System.out.println("该教工已经在休假中，请勿重复申请！");
            }else if (this.getState() == (short) 0){
                this.setState((short) 1);
                System.out.println("申请成功！");
                this.show();
            }
        }
    }

    //办理复工
    @Override
    public void goBackToSchool(int id) {
        if (this.getTea_id() == id){
            if (this.getState() == (short) 0){
                System.out.println("该教工已经在岗，请勿重复申请！");
            }else if (this.getState() == (short) 1){
                this.setState((short) 0);
                System.out.println("申请成功！");
                this.show();
            }
        }
    }

}
